const mongoose = require("mongoose");

const elderSchema = new mongoose.Schema({
  name: String,
  age: Number,
  phone: String
});

module.exports = mongoose.model("Elder", elderSchema);
