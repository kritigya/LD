const mongoose = require("mongoose");

const genzSchema = new mongoose.Schema({
  name: String,
  college: String,
  skills: String,
  verified: {
    type: Boolean,
    default: false
  },
  totalHoursWorked: {
    type: Number,
    default: 0
  },
  // rating: {
  //   type: Number,
  //   default: 0
  // }
}, { timestamps: true });

module.exports = mongoose.model("GenZ", genzSchema);
