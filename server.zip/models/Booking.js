const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({

  elder: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Elder"
  },

  genz: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "GenZ"
  },

  hours: Number,

  amount: Number,

  slot: String,

  status: {
    type: String,
    default: "Pending"
  },

  story: String,

  review: String,

  happyMomentMedia: String

}, {
  timestamps: true
});

module.exports = mongoose.model("Booking", bookingSchema);