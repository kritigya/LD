const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const elderRoutes = require("./routes/elders");
const genzRoutes = require("./routes/genz");
const bookingRoutes = require("./routes/bookings");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));
app.use("/api/elders", require("./routes/elders"));
app.use("/api/genz", require("./routes/genz"));

mongoose.connect("mongodb://127.0.0.1:27017/grandbuddy")
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

app.use("/api/elders", elderRoutes);
app.use("/api/genz", genzRoutes);
app.use("/api/bookings", bookingRoutes);

app.listen(5000, () => console.log("Server running on 5000"));
